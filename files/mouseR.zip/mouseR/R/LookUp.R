LookUp <- function(db, parents = NULL, strain = NULL,  cage = NULL, status = NULL, id = NULL, uid = NULL, dob = NULL, sex = NULL, location = FALSE, HideUID = TRUE, sort.by = 'Age'){
  dbgenes <- unique(unlist(lapply(db$MouseData,function(i){names(unlist(i$Genetics))})))
  temp1 <- data.frame(Strain = sapply(db$MouseData,function(i){i$Strain}),
                      UID = sapply(db$MouseData,function(i){i$UID}),
                      ID = sapply(db$MouseData,function(i){i$ID}),
                      DOB = as.Date(sapply(db$MouseData,function(i){i$DOB}), origin = '1970-01-01'),
                      Age = sapply(db$MouseData,function(i){i$Age}),
                      Sex = sapply(db$MouseData,function(i){i$Sex}),
                      Parents = sapply(db$MouseData,function(i){i$Parents}),
                      Cage = sapply(db$MouseData,function(i){i$Location$Cage}),
                      Status = sapply(db$MouseData,function(i){i$Status}))
  temp2 <- do.call(rbind,lapply(db$MouseData,function(i){
    t1 <- names(unlist(i$Genetics))
    t2 <- as.data.frame(matrix(nrow = 1, ncol = length(dbgenes), dimnames = list(i$UID,dbgenes)))
    t2[,match(t1,dbgenes)] <- unlist(i$Genetics)
    t2
  }))
  temp1 <- data.frame(temp1,temp2)
  if(!is.null(parents)){
    p1 <- unlist(lapply(temp1$Parents,function(q){strsplit(q,split = "\\|")[[1]][2]}))
    temp1 <- temp1[which(p1 %in% parents),]
  }
  if(!is.null(cage)){
    temp1 <- subset(temp1, Cage %in% cage)
  }
  if(!is.null(strain)){
    temp1 <- subset(temp1, Strain %in% strain)
  }
  if(!is.null(status)){
    temp1 <- subset(temp1, Status %in% status)
  }
  if(!is.null(id)){
    temp1 <- subset(temp1, ID %in% id)
  }
  if(!is.null(uid)){
    temp1 <- subset(temp1, UID %in% uid)
  }
  if(!is.null(dob)){
    temp1 <- subset(temp1, DOB %in% dob)
  }
  if(!is.null(sex)){
    temp1 <- subset(temp1, Sex %in% sex)
  }
  temp1[,which(sapply(1:ncol(temp1),function(i){length(which(is.na(temp1[,i]))) == nrow(temp1)}))] <- NULL
  if(nrow(temp1) == 0){
    temp1 <- writeLines('No matching mice.')
  }
  else{
    if(location == TRUE){
      df3 <- data.frame(do.call(rbind,lapply(1:nrow(temp1),function(i){
        cm <- temp1$UID[i]
        cm <- match(cm, sapply(db$MouseData,function(j){j$UID}))
        cd <- as.character()
        for(cg in c('Cage','Room','Rack','Row','Column')){
          cd <- c(cd,db$MouseData[[cm]]$Location[[cg]])
        }
        names(cd) <- c('Cage','Room','Rack','Row','Column')
        cd
      })))
      df3$Cage <- NULL
      temp1 <- data.frame(temp1,df3)
    }
    else{
      temp1 <- temp1
    }
    if(HideUID){
      temp1$UID <- NULL
    }
    else{
      temp1$UID <- temp1$UID
    }
    if(sort.by %in% colnames(temp1)){
      if(sort.by == 'Age'){
        d.i <- TRUE
      }
      else{
        d.i <- FALSE
      }
      temp1 <- temp1[order(temp1[,sort.by], decreasing = d.i),]
      temp1
    }
    else{
      writeLines('Value provided for sort.by is not a db column.')
      temp1 <- temp1[order(temp1[,'Age'], decreasing = TRUE),]
      temp1
    }
  }
}
