UpdateMice <- function(template = FALSE, db, sdir, currdate = FALSE){
  if(unlist(strsplit(sdir, split = ""))[nchar(sdir)] == "/"){
    sdir <- sdir
  }
  else{
    sdir <- paste0(sdir,'/')
  }
  if(template == TRUE){
    if(file.exists(paste0(sdir,Sys.Date(),'_changes.csv'))){
      writeLines(paste0('Template exists in ', sdir, ': ', Sys.Date(),'_changes.csv\nLeave cell blank (not NA) if no change.'))
    }
    else{
      writeLines(paste0('Template created. Find template in ', sdir, ': ', Sys.Date(),'_changes.csv\nLeave cell blank (not NA) if no change.'))
      write.csv(update_template,paste0(sdir,Sys.Date(),'_changes.csv'), row.names = FALSE)
    }
  }
  else{
    sdir1 <- list.files(sdir, pattern = '.csv')
    sf <- unlist(lapply(sdir1,function(i){substring(i,1,gregexpr("_",i)[[1]][1]-1)}))
    sdir1 <- sdir1[which(sf == currdate)]
    if(length(sdir1) == 0){
      db <- db
    }
    else{
      for(files in sdir1){
        df1 <- read.delim(paste0(sdir,files), row.names = NULL, stringsAsFactors = FALSE, sep = ",", colClasses = c('character'))
        for(n in 1:nrow(df1)){
          cm <- paste(df1$Mouse_id[n], df1$DOB[n], sep = ".")
          cm <- match(cm, sapply(db$MouseData,function(i){i$UID}))
          if(is.na(cm)){
            writeLines(paste0('Mouse ',df1$Mouse_id[n], ', DOB: ', df1$DOB[n],', not found. Please double check info.'))
          }
          else{
            to.update <- setdiff(colnames(df1),c('Strain','Mouse_id','DOB'))
            if('' %in% df1[n,to.update]){
              to.update <- to.update[-which(df1[n,to.update] == "")]
            }
            else{
              to.update <- to.update
            }
            if('Status' %in% to.update){
              ostatus <- db$MouseData[[cm]]$Status
              nstatus <- df1[n,'Status']
              if(length(db$MouseData[[cm]]$Location$Cage) == 0){
                tmp1 <- NA
              }
              else{
                tmp1 <- db$MouseData[[cm]]$Location$Cage
              }
              if(length(db$MouseData[[cm]]$History) > 0){
                df2 <- data.frame(db$MouseData[[cm]]$History)
              }
              else{
                df2 <- data.frame(Status = ostatus, Start_date = db$MouseData[[cm]]$DOB, Cage = tmp1)
              }
                if('Cage' %in% to.update){
                  tmp2 <- df1[n,'Cage']
                }
                else{
                  if(df1[n,'Status'] %in% c('Dead','Away')){
                    tmp2 <- NA
                  }
                  else{
                    tmp2 <- db$MouseData[[cm]]$Location$Cage
                  }
                }
                df2 <- rbind(df2,data.frame(Status = nstatus, Start_date = substring(files,1,regexpr('_changes.csv',files)-1), Cage = tmp2))
                db$MouseData[[cm]]$History <- df2
            }
            else{
              to.update <- to.update
            }
            for(m in to.update){
              if(df1[n,'Status'] %in% c('Dead','Away','Exp')){
                db$MouseData[[cm]]$Location$Room <- NA
                db$MouseData[[cm]]$Location$Rack <- NA
                db$MouseData[[cm]]$Location$Row <- NA
                db$MouseData[[cm]]$Location$Column <- NA
              }
              else{
                to.update <- to.update
              }
              if(m %in% c('Cage','Room','Rack','Row','Column')){
                cl <- match(m, names(db$MouseData[[cm]]$Location))
                db$MouseData[[cm]]$Location[[cl]] <- df1[n,m]
              }
              else{
                cs <- match(m, names(db$MouseData[[cm]]))
                db$MouseData[[cm]][[cs]] <- df1[n,m]
              }
            }
          }
        }
      }
      writeLines(paste(currdate,'info for indicated mice updated.'))
    }
    db
  }
}
