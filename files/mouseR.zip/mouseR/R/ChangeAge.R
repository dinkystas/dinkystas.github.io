ChangeAge <- function(db, new_unit = 'weeks'){
  db$MetaData$Age_format <- new_unit
  if(db$MetaData[['Age_format']] == 'days'){
    dv <- 1
  }
  if(db$MetaData[['Age_format']] == 'weeks'){
    dv <- 7
  }
  if(db$MetaData[['Age_format']] == 'months'){
    dv <- 365.2425/12
  }
  for(cm in 1:length(db$MouseData)){
    db$MouseData[[cm]][['Age']] <- round(as.integer(Sys.Date() - as.Date(db$MouseData[[cm]][['DOB']]))/dv,1)
  }
  db
}
