SetDV <- function(x){
  if(x == 'days'){
    dv <- 1
  }
  if(x == 'weeks'){
    dv <- 7
  }
  if(x == 'months'){
    dv <- 365.2425/12
  }
  dv
}
Parents <- function(db,x){
  bs <- which(grepl(x,sapply(db$MouseData,function(j){j$History$Cage[which(j$History$Status == 'Breed')]})))
  ms <- intersect(bs,which(sapply(db$MouseData,function(j){j$Sex == 'M'})))
  fs <- intersect(bs,which(sapply(db$MouseData,function(j){j$Sex == 'F'})))
  ms <- do.call(rbind,lapply(ms,function(j){
    dob <- db$MouseData[[j]]$DOB
    strain <- db$MouseData[[j]]$Strain
    bdate <- db$MouseData[[j]]$History
    edate <- as.character(bdate$Start_date[which(bdate$Status == 'Dead')])
    if(length(edate) == 0){
      edate <- NA
    }
    else{
      edate <- edate
    }
    bdate <- as.character(bdate$Start_date[intersect(which(bdate$Status == 'Breed'),which(bdate$Cage == x))])
    data.frame(Strain = strain, Mouse = db$MouseData[[j]]$ID, DOB = dob, BeginDate = bdate, EndDate = edate)
  }))
  fs <- do.call(rbind,lapply(fs,function(j){
    dob <- db$MouseData[[j]]$DOB
    strain <- db$MouseData[[j]]$Strain
    bdate <- db$MouseData[[j]]$History
    edate1 <- as.character(bdate$Start_date[intersect(intersect(which(bdate$Status == 'Breed'),which(bdate$Cage != x)), which(bdate$Start_date > bdate$Start_date[intersect(which(bdate$Status == 'Breed'),which(bdate$Cage == x))]))])
    edate2 <- as.character(bdate$Start_date[which(bdate$Status == 'Dead')])
    if(length(edate1) == 0){
      if(length(edate2) == 0){
        edate <- NA
      }
      else{
        edate <- edate2
      }
    }
    else{
      edate <- edate1
    }
    bdate <- as.character(bdate$Start_date[intersect(which(bdate$Status == 'Breed'),which(bdate$Cage == x))])
    data.frame(Strain = strain, Mouse = db$MouseData[[j]]$ID, DOB = dob, BeginDate = bdate, EndDate = edate)
  }))
  tmp <- list(Males = ms, Females = fs)
  tmp
}