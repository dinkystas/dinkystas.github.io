BreederAges <- function(db, bdb, old = FALSE, strain = NULL){
  df1 <- data.frame(do.call(rbind,lapply(bdb,function(i){
    dv <- SetDV(db$MetaData$Age_format)
    df2 <- i$CurrentTrio[c('M','F','F.1')]
    df3 <- rbind(i$Males,i$Females)
    df3 <- droplevels(subset(df3, is.na(df3$EndDate)))
    df3 <- round((Sys.Date() - as.Date(df3$DOB[match(df2,df3$Mouse)]))/dv,1)
    df4 <- paste(i$Strain, collapse = ",")
    c(df4,df2,df3)
    })))
  colnames(df1) <- c('Strain','M_ID','F1_ID','F2_ID','M_age','F1_age','F2_age')
  df1$M_age <- as.numeric(df1$M_age)
  df1$F1_age <- as.numeric(df1$F1_age)
  df1$F2_age <- as.numeric(df1$F2_age)
  if(old == FALSE){
    df1 <- df1
  }
  else{
    df1 <- df1[which(df1$M_age > old | df1$F1_age > old | df1$F2_age > old),]
  }
  if(is.null(strain)){
    df1 <- df1
  }
  else{
    df1 <- df1[unique(unlist(lapply(strain,function(i){grep(i,df1$Strain)}))),]
  }
  df1
}
