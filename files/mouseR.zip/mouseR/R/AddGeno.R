AddGeno <- function(db, gdir, currdate = FALSE){
  if(unlist(strsplit(gdir, split = ""))[nchar(gdir)] == "/"){
    gdir <- gdir
  }
  else{
    gdir <- paste0(gdir,'/')
  }
  gdir1 <- list.files(gdir, pattern = '.csv')
  gf <- unlist(lapply(gdir1,function(i){substring(i,1,gregexpr("_",i)[[1]][1]-1)}))
  gdir1 <- gdir1[which(gf == currdate)]
  if(length(gdir1) == 0){
    db <- db
  }
  else{
    for(files in gdir1){
      df1 <- read.csv(paste0(gdir,files), row.names = NULL, stringsAsFactors = FALSE, colClasses = 'character')
      for(n in 1:nrow(df1)){
        cstrain <- df1$Strain[n]
        cm <- paste(df1$Mouse_id[n], df1$DOB[n], sep = ".")
        cm <- match(cm, sapply(db$MouseData,function(i){i$UID}))
        cgenes <- unlist(strsplit(db$StrainInfo$Genes[match(cstrain,db$StrainInfo$Strain)], split = ","))
        for(m in cgenes){
          cv <- as.character(df1[n,match(as.character(m),colnames(df1))])
          cv <- paste(sort(unlist(strsplit(cv, split = "/"))), collapse = "/")
          cg <- match(m, names(db$MouseData[[cm]]$Genetics))
          db$MouseData[[cm]]$Genetics[[cg]] <- cv
        }
      }
    }
    writeLines(paste(currdate,'genotypes updated.'))
  }
  db
}
