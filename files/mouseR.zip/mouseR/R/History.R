History <- function(db, id = NULL){
  cm <- as.vector(sapply(id, function(a){
    unname(which(sapply(db$MouseData,function(i){i$ID}) == as.character(a)))
    }))
  lapply(db$MouseData[cm], function(i){i$History})
}
