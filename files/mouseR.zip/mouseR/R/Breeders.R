Breeders <- function(db, current = TRUE){
  if(current == TRUE){
    uc <- which(sapply(db$MouseData,function(i){i$Status}) == 'Breed')
    uc <- unique(sapply(db$MouseData[uc],function(i){i$Location$Cage}))
  }
  else{
    uc <- unique(do.call(rbind,lapply(db$MouseData,function(i){i$History[which(i$History$Status == 'Breed'),]}))$Cage)
  }
  bdb <- lapply(uc,function(i){
    bs <- which(grepl(i,sapply(db$MouseData,function(j){j$History$Cage[which(j$History$Status == 'Breed')]})))
    ms <- intersect(bs,which(sapply(db$MouseData,function(j){j$Sex == 'M'})))
    fs <- intersect(bs,which(sapply(db$MouseData,function(j){j$Sex == 'F'})))
    ms <- do.call(rbind,lapply(ms,function(j){
      dob <- db$MouseData[[j]]$DOB
      strain <- db$MouseData[[j]]$Strain
      bdate <- db$MouseData[[j]]$History
      edate <- as.character(bdate$Start_date[which(bdate$Status == 'Dead')])
      if(length(edate) == 0){
        edate <- NA
      }
      else{
        edate <- edate
      }
      bdate <- as.character(bdate$Start_date[intersect(which(bdate$Status == 'Breed'),which(bdate$Cage == i))])
      data.frame(Strain = strain, Mouse = db$MouseData[[j]]$ID, DOB = dob, BeginDate = bdate, EndDate = edate)
    }))
    fs <- do.call(rbind,lapply(fs,function(j){
      dob <- db$MouseData[[j]]$DOB
      strain <- db$MouseData[[j]]$Strain
      bdate <- db$MouseData[[j]]$History
      edate1 <- as.character(bdate$Start_date[intersect(intersect(which(bdate$Status == 'Breed'),which(bdate$Cage != i)), which(bdate$Start_date > bdate$Start_date[intersect(which(bdate$Status == 'Breed'),which(bdate$Cage == i))]))])
      edate2 <- as.character(bdate$Start_date[which(bdate$Status == 'Dead')])
      if(length(edate1) == 0){
        if(length(edate2) == 0){
          edate <- NA
        }
        else{
          edate <- edate2
        }
      }
      else{
        edate <- edate1
      }
      bdate <- as.character(bdate$Start_date[intersect(which(bdate$Status == 'Breed'),which(bdate$Cage == i))])
      data.frame(Strain = strain, Mouse = db$MouseData[[j]]$ID, DOB = dob, BeginDate = bdate, EndDate = edate)
    }))
    ct <- c(ms$Mouse[which(is.na(ms$EndDate))],sort(fs$Mouse[which(is.na(fs$EndDate))]))
    strain <- unique(c(ms$Strain,fs$Strain))
    names(ct) <- make.unique(c(rep('M', times = length(ms$Mouse[which(is.na(ms$EndDate))])), rep('F', times = length(fs$Mouse[which(is.na(fs$EndDate))]))))
    pid1 <- sapply(db$MouseData,function(j){strsplit(j$Parents,split = "\\|")[[1]][1]})
    pid2 <- sapply(db$MouseData,function(j){strsplit(j$Parents,split = "\\|")[[1]][2]})
    litters <- which(pid2 == as.character(i))
    if(length(litters) > 0){
      litters <- unique(as.Date(sapply(db$MouseData[litters],function(j){j$DOB}), origin = "1970-01-01"))
      litters <- do.call(rbind,lapply(litters,function(j){
        cd <- as.Date(j)
        cms <- intersect(which(sapply(db$MouseData,function(k){k$DOB}) == cd),which(pid2 == as.character(i)))
        ids <- paste(unname(sort(sapply(db$MouseData[cms],function(k){k$ID}))), collapse = ',')
        cs <- paste(unique(unname(sapply(db$MouseData[cms],function(k){k$Strain}))), collapse = ',')
        cp <- unique(pid1[cms])
        cfs <- length(which(sapply(db$MouseData[cms],function(k){k$Sex}) == 'F'))
        cms <- length(which(sapply(db$MouseData[cms],function(k){k$Sex}) == 'M'))
        data.frame(Strain = cs, DOB = cd, N_M = cms, N_F = cfs, IDs = ids, Parents = cp)
      }))
    }
    else{
      litters <- data.frame(Strain = NA, DOB = NA, N_M = NA, N_F = NA, IDs = NA, Parents = NA)
    }
    if(is.na(unique(litters$Strain))){
      strain <- strain
    }
    else{
      if(length(strain) > 1){
        strain <- unique(litters$Strain)
      }
      else{
        strain <- strain
      }
    }
    tmp <- list(Cage = as.character(i), Strain = strain, Males = ms, Females = fs, CurrentTrio = ct, Litters = litters)
  })
  names(bdb) <- uc
  bdb
}
