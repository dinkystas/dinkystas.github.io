MouseSetup <- function(strains = NULL, meta = NULL, mice = NULL, mdir = NULL, gdir = NULL, sdir = NULL, setdate = Sys.Date()){
  if(is.null(meta)){
    writeLines('Please provide additional meta information as a data.frame or csv file.\n -See template for details.\n -A template has been generated in the wd (meta_template.csv)')
    write.csv(meta_template, 'meta_template.csv', row.names = FALSE)
  }
  else{
    if(is.character(meta)){
      meta <- read.csv(meta, row.names = NULL, stringsAsFactors = FALSE)
    }
    else{
      meta <- meta
    }
    tn <- meta$Parameter
    meta <- as.list(meta$Value)
    names(meta) <- tn
    rm(tn)
    writeLines('Meta info populated.')
  }
  if(is.null(strains)){
    writeLines('Please provide mouse strain information as a data.frame or csv file.\n -Genes should indicate potentially targeted (non-WT) alleles and be a comma separated list without spaces.\n -A template has been generated in the wd (strain_info_template.csv)')
    if(exists(meta)){
      if(meta$Strain_tag_same == 'TRUE'){
        write.csv(strain_info_template, 'strain_info_template.csv', row.names = FALSE)
      }
      else{
        write.csv(strain_info_template_v2, 'strain_info_template.csv', row.names = FALSE)
      }
    }
    else{
      write.csv(strain_info_template, 'strain_info_template.csv', row.names = FALSE)
    }
  }
  else{
    if(is.character(strains)){
      strains <- read.csv(strains, row.names = NULL, stringsAsFactors = FALSE)
    }
    else{
      strains <- strains
    }
    writeLines('Strain info populated.')
  }
    if(is.null(mice)){
      writeLines('Please provide mouse information as a data.frame or csv file using this function.\n -A template has been generated in the wd (mouse_data_template.csv). Missing info is allowed.')
      write.csv(mouse_data_template, 'mouse_data_template.csv', row.names = FALSE)
    }
    else{
      if(is.character(mice)){
        mice <- read.csv(mice, row.names = NULL, stringsAsFactors = FALSE)
      }
      else{
        mice <- mice
      }
    }
  if(length(which(c(is.null(meta),is.null(strains),is.null(mice)))) == 3){
    writeLines('After filling out templates, try again.')
  }
  else{
    dv <- SetDV(meta[['Age_format']])
      mice$Age <- round(as.integer(Sys.Date() - as.Date(mice$DOB))/dv,1)
      for(n in 1:ncol(mice)){
        mice[which(mice[,n] == ""),n] <- NA
      }
      mice <- mice[which(mice$Strain %in% strains$Strain),]
      mice <- lapply(1:nrow(mice),function(i){
        cstrain <- mice$Strain[i]
        cgenes <- unlist(strsplit(strains$Genes[match(cstrain,strains$Strain)], split = ","))
        cgenes1 <- lapply(cgenes,function(j){
          paste(sort(unlist(strsplit(mice[i,match(as.character(j),colnames(mice))], split = "/"))), collapse = "/")
        })
        names(cgenes1) <- cgenes
        dft <- data.frame(Status = 'Born', Start_date = as.Date(mice$DOB[i]), Cage = NA)
        dft <- as.data.frame(rbind(dft,data.frame(Status = mice$Status[i], Start_date = NA, Cage = mice$Cage[i])))
        m.info <- list(ID = mice$Mouse_id[i],
                       UID = paste(mice$Mouse_id[i], mice$DOB[i], sep = "."),
                       Strain = mice$Strain[i],
                       Parents = paste0(mice$M_parent[i],'*',mice$F_parent1[i],'_',mice$F_parent2[i]),
                       Sex = mice$Sex[i],
                       DOB = as.Date(mice$DOB[i]),
                       Age = round(as.integer(Sys.Date() - as.Date(mice$DOB[i]))/dv,1),
                       Status = mice$Status[i],
                       Location = list(Cage = mice$Cage[i],
                                       Room = mice$Room[i],
                                       Rack = mice$Rack[i],
                                       Row = mice$Row[i],
                                       Column = mice$Column[i]),
                       Genetics = cgenes1,
                       History = dft)
      })
      names(mice) <- make.unique(unlist(lapply(mice,function(i){i$ID})))
      writeLines('Mouse info populated.')
  mdb <- list(MetaData = meta, StrainInfo = strains, MouseData = mice)
  if(is.null(c(mdir,gdir,sdir))){
    mdb
  }
  else{
    af <- list.files(path = c(mdir,gdir,sdir))
    af <- unique(unlist(lapply(af,function(i){substring(i,1,gregexpr("_",i)[[1]][1]-1)})))
    af <- af[which(as.Date(af) <= as.Date(setdate))]
    for(n in af){
      d1 <- as.character(n)
      mdb <- AddMice(template = FALSE, db = mdb, mdir = mdir, gdir = gdir, currdate = d1)
      mdb <- AddGeno(db = mdb, gdir = gdir, currdate = d1)
      mdb <- UpdateMice(template = FALSE, db = mdb, sdir = sdir, currdate = d1)
    }
    mdb
  }}
}
