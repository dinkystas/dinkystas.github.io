AddMice <- function(template = FALSE, db, mdir, gdir, currdate = FALSE){
  if(unlist(strsplit(mdir, split = ""))[nchar(mdir)] == "/"){
    mdir <- mdir
  }
  else{
    mdir <- paste0(mdir,'/')
  }
  if(template == TRUE){
    if(file.exists(paste0(mdir,Sys.Date(),'_mice.csv'))){
      writeLines(paste0('Template exists in ', mdir, ': ', Sys.Date(),'_mice.csv'))
    }
    else{
      writeLines(paste0('Find template in ', mdir, ': ', Sys.Date(),'_mice.csv'))
      if(db$MetaData$Strain_tag_same){
        write.csv(add_mice_template,paste0(mdir,Sys.Date(),'_mice.csv'), row.names = FALSE)
      }
      else{
        write.csv(add_mice_template_v2,paste0(mdir,Sys.Date(),'_mice.csv'), row.names = FALSE)
      }
    }
  }
  else{
    if(unlist(strsplit(gdir, split = ""))[nchar(gdir)] == "/"){
      gdir <- gdir
    }
    else{
      gdir <- paste0(gdir,'/')
    }
    mdir1 <- list.files(mdir, pattern = '.csv')
    mf <- unlist(lapply(mdir1,function(i){substring(i,1,gregexpr("_",i)[[1]][1]-1)}))
    mdir1 <- mdir1[which(mf == currdate)]
    gdir1 <- list.files(gdir, pattern = '.csv')
    gf <- unlist(lapply(gdir1,function(i){substring(i,1,gregexpr("_",i)[[1]][1]-1)}))
    gdir1 <- gdir1[which(gf == currdate)]
    if(length(mdir1) == 0){
      db <- db
    }
    else{
      dv <- SetDV(db$MetaData$Age_format)
      for(files in mdir1){
        MouseData <- read.csv(paste0(mdir,files), row.names = NULL, stringsAsFactors = FALSE, colClasses = c(Strain = 'character'))
        MouseData$Age <- round(as.integer(Sys.Date() - as.Date(MouseData$DOB))/dv,1)
        MouseData <- MouseData[which(MouseData$Strain %in% db$StrainInfo$Strain),]
        MouseData$Strain_v2 <- make.unique(MouseData$Strain, sep = "_")
        bdb <- lapply(MouseData$ParentCage,function(i){
          if(is.na(i)){
            return(NA)
          }
          else{
            bdbt <- Parents(db,as.character(i))
            ta <- bdbt$Males
            ta$BeginDate[which(is.na(ta$BeginDate))] <- as.character((as.Date(currdate) - 21))
            ta <- ta[which(as.Date(ta$BeginDate) < (as.Date(currdate) - 18)),]
            ta$EndDate[which(is.na(ta$EndDate))] <- currdate
            ta <- ta[which(as.Date(ta$EndDate) > (as.Date(currdate) - 18)),]
            tm <- ta$Mouse
            ta <- bdbt$Females
            ta$BeginDate[which(is.na(ta$BeginDate))] <- as.character((as.Date(currdate) - 21))
            ta <- ta[which(as.Date(ta$BeginDate) < (as.Date(currdate) - 18)),]
            ta$EndDate[which(is.na(ta$EndDate))] <- currdate
            ta <- ta[which(as.Date(ta$EndDate) > (as.Date(currdate) - 18)),]
            tf <- ta$Mouse
            bdbt$Males <- subset(bdbt$Males, Mouse %in% tm)
            bdbt$Females <- subset(bdbt$Females, Mouse %in% tf)
            bdbt$Cage <- as.character(i)
            return(bdbt)
          }
          })
        MouseData$Parents <- unlist(lapply(bdb,function(i){
          suppressWarnings(if(is.na(i)[1]){
            ta <- paste('NA','NA', sep = "|")
          }
          else{
            tm <- i$Males$Mouse
            tf <- i$Females$Mouse
            ta <- paste0(c(sort(tm),paste0(sort(tf), collapse = "_")), collapse = "*")
            ta <- paste(ta,i$Cage,sep = "|")
          })
        }))
        MouseData <- do.call(rbind,lapply(1:nrow(MouseData),function(i){
          cgenes <- unlist(strsplit(db$StrainInfo$Genes[match(MouseData$Strain[i],db$StrainInfo$Strain)], split = ","))
          if(is.na(suppressWarnings(as.integer(MouseData$Start_id[i])))){
            dft <- data.frame(Strain = MouseData$Strain[i],
                              Parents = MouseData$Parents[i],
                              Mouse_id = MouseData$Start_id[i],
                              Sex = c(rep('M',MouseData$N_M[i]),rep('F',MouseData$N_F[i])),
                              DOB = MouseData$DOB[i],
                              Age = MouseData$Age[i])
            dft$Mouse_id <- make.unique(dft$Mouse_id)
          }
          else{
            tid <- as.integer(MouseData$Start_id[i])
            tid <- tid:(tid+sum(MouseData$N_M[i],MouseData$N_F[i])-1)
            tid[which(tid > as.integer(db$MetaData$Max_id_number))] <- 1:length(which(tid > as.integer(db$MetaData$Max_id_number)))
            if(db$MetaData$Strain_tag_same){
              mid <- paste0(MouseData$Strain[i],formatC(tid, width = nchar(db$MetaData$Max_id_number), format = 'd', flag = "0"))
            }
            else{
              if(MouseData$Override_tag[i] != ''){
                mid <- paste0(db$StrainInfo$Tag[which(db$StrainInfo$Strain == MouseData$Strain[i])],formatC(tid, width = nchar(db$MetaData$Max_id_number), format = 'd', flag = "0"))
              }
              else{
                mid <- paste0(MouseData$Override_tag[i],formatC(tid, width = nchar(db$MetaData$Max_id_number), format = 'd', flag = "0"))
              }
            }
            dft <- data.frame(Strain = MouseData$Strain[i],
                              Parents = MouseData$Parents[i],
                              Mouse_id = mid,
                              Sex = c(rep(db$MetaData$First_tagged,MouseData[[paste0('N_',db$MetaData$First_tagged)]][i]),rep(setdiff(c('M','F'),db$MetaData$First_tagged),MouseData[[paste0('N_',setdiff(c('M','F'),db$MetaData$First_tagged))]][i])),
                              DOB = MouseData$DOB[i],
                              Age = MouseData$Age[i])
          }
          if(MouseData$Genotypes[i] == 'Yes'){
            cd <- unlist(strsplit(files, split = "_"))[1]
            cd <- paste0(cd,'_',MouseData$Strain_v2[i],'.csv')
            if(cd %in% gdir1){
              cd <- NULL
            }
            else{
              ptemp <- bdb[[i]]
              df2 <- as.data.frame(do.call(rbind,lapply(1:nrow(dft),function(j){
                cp <- dft$Mouse_id[j]
                cs <- dft$Sex[j]
                suppressWarnings(if(is.na(ptemp)[1]){
                  return(as.data.frame(matrix(nrow = 1, ncol = length(cgenes), dimnames = list(cp,cgenes))))
                }
                else{
                  t1 <- unique(paste(ptemp$Males$Mouse,ptemp$Males$DOB, sep = "."))
                  t1 <- db$MouseData[which(sapply(db$MouseData,function(k){k$UID}) %in% t1)]
                  t2 <- unique(paste(ptemp$Females$Mouse,ptemp$Females$DOB, sep = "."))
                  t2 <- db$MouseData[which(sapply(db$MouseData,function(k){k$UID}) %in% t2)]
                  t3 <- do.call(cbind,lapply(cgenes,function(k){
                    t4 <- as.character(k)
                    t5 <- unique(unlist(lapply(t1,function(l){
                      if(is.null(l$Genetics[[t4]])){
                        return("?")
                      }
                      else{
                        if(is.na(l$Genetics[[t4]])){
                          return("?")
                        }
                        else{
                          return(unlist(strsplit(l$Genetics[[t4]], split = "/"))) 
                        }
                      }
                      })))
                    if('Y' %in% t5){
                      if(cs == 'M'){
                        t5 <- 'Y'
                      }
                      else{
                        t5 <- setdiff(t5,'Y')
                      }
                    }
                    else{
                      t5 <- t5
                    }
                    t6 <- unique(unlist(lapply(t2,function(l){
                      if(is.null(l$Genetics[[t4]])){
                        return("?")
                      }
                      else{
                        if(is.na(l$Genetics[[t4]])){
                          return("?")
                        }
                        else{
                          return(unlist(strsplit(l$Genetics[[t4]], split = "/")))
                        }
                      }
                      })))
                    if(length(t5) == 1){
                      t5 <- t5
                    }
                    else{
                      t5 <- '?'
                    }
                    if(length(t6) == 1){
                      t6 <- t6
                    }
                    else{
                      t6 <- '?'
                    }
                    t7 <- c(t5,t6)
                    return(paste(sort(t7), collapse = "/"))
                  }))
                  names(t3) <- cgenes
                  return(t3)
                })
              })))
              colnames(df2) <- cgenes
              write.csv(data.frame(dft[,c('Strain','Parents','Mouse_id','Sex','DOB')],df2),paste0(gdir,cd), row.names = FALSE)
            }
          }
          else{
            cd <- NULL
          }
          dft}))
        cmice <- unlist(lapply(db$MouseData,function(i){i$UID}))
        MouseData <- lapply(1:nrow(MouseData),function(i){
          cgenes <- unlist(strsplit(db$StrainInfo$Genes[match(MouseData$Strain[i],db$StrainInfo$Strain)], split = ","))
          if(paste(MouseData$Mouse_id[i], MouseData$DOB[i], sep = ".") %in% cmice){
            writeLines('Potential duplicate tried to be added. Please check database.')
          }
          else{
            cgenes1 <- lapply(cgenes,function(j){
              return(NA)
            })
            names(cgenes1) <- cgenes
            dft <- data.frame(Status = 'Born', Start_date = as.Date(MouseData$DOB[i]), Cage = NA)
            m.info <- list(ID = MouseData$Mouse_id[i],
                           UID = paste(MouseData$Mouse_id[i], MouseData$DOB[i], sep = "."),
                           Strain = MouseData$Strain[i],
                           Parents = MouseData$Parents[i],
                           Sex = MouseData$Sex[i],
                           DOB = as.Date(MouseData$DOB[i]),
                           Age = round(as.integer(Sys.Date() - as.Date(MouseData$DOB[i]))/dv,1),
                           Status = 'Pup',
                           Location = list(Cage = NA,
                                           Room = NA,
                                           Rack = NA,
                                           Row = NA,
                                           Column = NA),
                           Genetics = cgenes1,
                           History = dft)
          }
        })
        MouseData[sapply(MouseData, is.null)] <- NULL
        db$MouseData <- c(db$MouseData,MouseData)
        names(db$MouseData) <- make.unique(unlist(lapply(db$MouseData,function(i){i$ID})))
      }
      writeLines(paste(currdate,'mice added to database.'))
    }
    db}
}
