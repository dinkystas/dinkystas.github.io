CageLabel <- function(db, id = NULL, cage = NULL, uid = NULL, location = NULL, blanks = NULL, filename = 'to_print'){
  if(!is.null(cage)){
    uid <- lapply(cage,function(a){
      LookUp(db, cage = a, location = FALSE, HideUID = FALSE, status = c('Breed','Weaned','Pup'))$UID
    })
  }
  else{
    if(is.null(uid)){
      if(!is.list(dob)){
        dob <- list(dob)
      }
      else{
        dob <- dob
      }
      if(!is.list(id)){
        id <- list(id)
      }
      else{
        id <- id
      }
      uid <- lapply(seq_along(id),function(a){
        if(length(unique(dob[[a]])) == 1){
          tdob <- rep(dob[[a]], times = length(id[[a]]))
        }
        else{
          tdob <- dob[[a]]
        }
        tuid <- paste(id[[a]], tdob, sep = ".")
        tuid
      })
    }
    else{
      uid <- uid
    }
  }
  if(length(uid) > 15){
    writeLines("Please submit 15 or fewer cage labels to print.")
  }
  else{
    if(is.null(blanks)){
      tuid <- as.list(1:15)
      tuid[(1+length(uid)):15] <- NA
      tuid[which(!is.na(tuid))] <- uid
      uid <- tuid
    }
    else{
      tuid <- as.list(1:15)
      tuid[blanks] <- NA
      if((length(blanks)+length(uid)) <15){
        tuid[(1+length(blanks)+length(uid)):15] <- NA
      }
      else{
        tuid <- tuid
      }
      tuid[which(!is.na(tuid))] <- uid
      uid <- tuid
    }
    phuid <- tail(LookUp(db, status = 'Weaned')$Cage,1)
    phuid <- LookUp(db, cage = phuid, location = FALSE, HideUID = FALSE, status = c('Breed','Weaned','Pup'))$UID
    dfs <- lapply(seq_along(uid),function(a){
      if(is.na(uid[a])){
        df1 <- LookUp(db, uid = phuid, location = TRUE, HideUID = FALSE)
        tmp2 <- "#FFFFFF"
        tmp1 <- ggplot2::theme(axis.line = ggplot2::element_blank(),
                                       axis.ticks = ggplot2::element_blank(),
                                       panel.background = ggplot2::element_blank(),
                                       panel.grid = ggplot2::element_blank(),
                                       axis.title = ggplot2::element_blank(),
                                       axis.text.y = ggplot2::element_blank(),
                                       axis.text.x = ggplot2::element_text(size = 8, angle = 30, face = 'bold', color = '#FFFFFF', margin = ggplot2::margin(0.1,0,0,0, unit = 'in')),
                                       plot.margin = ggplot2::margin(0.15,0.15,0.15,0.05, unit = 'in'),
                                       text = ggplot2::element_text(color = '#FFFFFF'),
                                       line = ggplot2::element_line(color = '#FFFFFF'))
      }
      else{
        df1 <- LookUp(db, uid = uid[[a]], location = TRUE, HideUID = FALSE)
        tmp2 <- "#000000"
        tmp1 <- ggplot2::theme(axis.line = ggplot2::element_blank(),
                                       axis.ticks = ggplot2::element_blank(),
                                       panel.background = ggplot2::element_blank(),
                                       panel.grid = ggplot2::element_blank(),
                                       axis.title = ggplot2::element_blank(),
                                       axis.text.y = ggplot2::element_blank(),
                                       axis.text.x = ggplot2::element_text(size = 6, angle = 30, face = 'bold', color = 'black', margin = ggplot2::margin(0.1,0,0,0, unit = 'in')),
                                       plot.margin = ggplot2::margin(0.15,0.15,0.15,0.05, unit = 'in'))
      }
      if(!is.null(location)){
        tloc <- location[[a]]
      }
      else{
        if('Rack' %in% colnames(df1)){
          tloc <- paste0(unique(df1$Room),'-',unique(df1$Rack),' ', unique(df1$Row),unique(df1$Column))
        }
        else{
          tloc <- "Undefined"
        }
      }
      dfcn <- setdiff(colnames(df1),c('Strain','UID','Age','Parents','Cage','Status','Room','Rack','Row','Column'))
      tstrain <- paste0(unique(df1$Strain), collapse = ",")
      df1 <- df1[,dfcn]
      dfcn <- setdiff(dfcn,c('ID','DOB','Sex'))
      df1 <- data.frame(prow = rep(seq(from = (3.9-.25), to = (3.9-.5-(.5*(length(unique(df1$ID))-1))), by = -.5), times = ncol(df1)), pcol = rep(colnames(df1), each = nrow(df1)), pval = unname(unlist(df1)))
      df1$pval[which(df1$pcol == 'DOB')] <- as.character(format(as.Date(as.numeric(df1$pval[which(df1$pcol == 'DOB')]), origin = "1970-01-01"), "%m/%d/%y"))
      df1$n_char <- nchar(df1$pval)
      df1$pval[which(df1$pcol %in% dfcn)] <- unlist(lapply(df1$pval[which(df1$pcol %in% dfcn)],function(b){
        paste(unlist(strsplit(as.character(b), split = "/")), collapse = "\n")
      }))
      tv <- tapply(df1$n_char,df1$pcol, max, na.rm = TRUE)
      p1 <- ggplot2::ggplot(data = df1, ggplot2::aes(pcol,prow)) +
        ggplot2::geom_text(ggplot2::aes(label = pval), size = 2, family = 'Helvetica-Narrow', color = tmp2) +
        ggplot2::annotate(x = length(unique(df1$pcol)), y = .4, label = paste0('Location:\n',tloc), geom = 'text', hjust = 1, size = 2.5, fontface = 'bold', color = tmp2) +
        ggplot2::annotate(x = 1, y = .4, label = paste0('Strain:\n',tstrain), geom = 'text', hjust = 0, size = 2.5, fontface = 'bold', color = tmp2) +
        ggplot2::geom_hline(yintercept = unique(df1$prow)-.25, size = .2, color = tmp2) +
        ggplot2::scale_y_continuous(limits = c(0,4.1), expand = ggplot2::expansion(mult = 0, add = 0)) +
        ggplot2::scale_x_discrete(limits = c('ID','DOB','Sex',dfcn), position = 'top', expand = ggplot2::expansion(mult = c(0.07,0.12), add = 0), labels = abbreviate(c('ID','DOB','Sex',dfcn), minlength = 5)) +
        tmp1
      p1
    })
    pall <- patchwork::wrap_plots(dfs, ncol = 5, nrow = 3, byrow = FALSE)
    ggplot2::ggsave(paste0(filename,'.pdf'), height = 8.5, width = 10.2, paper = 'USr')
  }
}
