RackPlot <- function(status = c('Weaned','Breed'), rack = NA, db = mouse.db){
  p1.df <- LookUp(db, status = status, location = TRUE)[,c('Cage','Rack','Column','Row')]
  if(is.na(rack)){
    p1.df <- p1.df
  }
  else{
    p1.df <- p1.df[which(p1.df$Rack %in% rack),]
  }
  p1.df <- merge(unique(p1.df), data.frame(Cage = names(table(p1.df$Cage)), Count = as.vector(table(p1.df$Cage))), by = "Cage")
  p1 <- ggplot2::ggplot(data = p1.df, ggplot2::aes(Column, Row)) +
    ggplot2::facet_grid(.~Rack) +
    ggplot2::geom_tile(fill = "#FFFFFF", color = "#000000", size = 1, height = 0.9, width = 0.9) +
    ggplot2::geom_text(ggplot2::aes(label = Cage), size = 3, hjust = 0.5, vjust = 1) +
    ggplot2::geom_text(ggplot2::aes(label = Count), size = 3, hjust = 0.5, vjust = 0) +
    ggplot2::scale_y_discrete(limits = rev(sort(unique(p1.df$Row)))) +
    ggplot2::theme(axis.line.x = ggplot2::element_line(color = '#000000', size = 0.5, lineend = 'round'),
                   axis.line.y = ggplot2::element_line(color = '#000000', size = 0.5, lineend = 'round'),
                   axis.ticks = ggplot2::element_line(color = 'black', size = 0.5, lineend = 'round'),
                   axis.ticks.length = ggplot2::unit(4,'points'),
                   panel.background = ggplot2::element_rect(fill = 'white'),
                   text = ggplot2::element_text(size = 10, color = 'black'),
                   axis.text = ggplot2::element_text(size = 10, color = 'black'))
  p1
}
