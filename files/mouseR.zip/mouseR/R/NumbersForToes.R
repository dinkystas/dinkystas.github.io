NumbersForToes <- function(db){
  if(db$MetaData$Strain_tag_same == 'TRUE'){
    temp1 <- data.frame(ca = unlist(lapply(db$MouseData,function(i){i$Strain})),
                        cb = unlist(lapply(db$MouseData,function(i){i$ID})),
                        cc = as.Date(unlist(lapply(db$MouseData,function(i){as.character(i$DOB)}))))
    v1 <- db$StrainInfo$Strain
    v2 <- 'Strain'
  }
  else{
    temp1 <- data.frame(ca = unlist(lapply(db$MouseData,function(i){i$Strain})),
                        cb = unlist(lapply(db$MouseData,function(i){i$ID})),
                        cc = as.Date(unlist(lapply(db$MouseData,function(i){as.character(i$DOB)}))))
    temp1$ca <- sapply(1:nrow(temp1),function(i){db$StrainInfo$Tag[which(db$StrainInfo$Strain == ca[i])]})
    v1 <- unique(db$StrainInfo$Tag)
    v2 <- 'Tag'
  }
  rv2 <- do.call(rbind,lapply(v1,function(i){
    temp2 <- temp1[which(temp1$ca == as.character(i)),]
    if(nrow(temp2) == 0){
      temp2 <- 1
    }
    else{
      temp2 <- temp2[order(temp2$cc, na.last = FALSE),]
      temp2 <- temp2$cb[nrow(temp2)]
      temp3 <- paste0(unlist(strsplit(temp2, split = ''))[-which(unlist(strsplit(temp2, split = '')) %in% unlist(strsplit(as.character(i),split = '')))], collapse = '')
      if(is.na(as.integer(temp3))){
        temp2 <- 1
      }
      else{
        if(temp3 %in% formatC(1:db$MetaData$Max_id_number, width = nchar(db$MetaData$Max_id_number), format = 'd', flag = "0")){
          temp2 <- as.integer(temp3) + 1
        }
        else{
          temp2 <- 1
        }
        if(is.na(temp2)){
          temp2 <- 1
        }
        else{
          if(temp2 > as.integer(db$MetaData$Max_id_number)){
            temp2 <- 1
          }
          else{
            temp2 <- temp2
          }
        }
      }
    }
    temp2 <- formatC(temp2, width = nchar(db$MetaData$Max_id_number), format = 'd', flag = "0")
    temp2 <- data.frame(as.character(i),temp2)
    colnames(temp2) <- c(v2,'Next_number')
    temp2
  }))
  rv2
}
